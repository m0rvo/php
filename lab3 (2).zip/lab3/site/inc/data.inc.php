<?php
declare(strict_types=1);

$menu = [
    ['link' => 'Домой', 'href' => 'index.php'],
    ['link' => 'О нас', 'href' => 'about.php'],
    ['link' => 'Контакты', 'href' => 'contact.php'],
    ['link' => 'Таблица', 'href' => 'table.php'],
    ['link' => 'Калькулятор', 'href' => 'calc.php'],
];