<h2>Навигация по сайту</h2>
<?php getMenu($menu); ?>